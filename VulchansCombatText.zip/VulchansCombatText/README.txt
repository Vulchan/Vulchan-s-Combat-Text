VULCHAN'S COMBAT TEXT 0.3.4

INSTALL
1. Close Azeroth Survivors.
2. Replace the existing VulchansCombatText folder in AddOns with this folder.
3. Launch the game and start a run.

TEST
Type /vct test. The test tries to show icons for Shadow Bolt, Corruption and Melee.
Real outgoing spell hits use the spell name parsed from the combat message and
look up that spell in your spellbook. Melee uses the equipped main-hand weapon.

Commands:
/vct on
/vct off
/vct test
/vct icons on
/vct icons off
/vct iconsize 22
/vct reset

NOTES
- This is standalone and does not load or alter Survivor UI.
- Spell icons are resolved from the player's spellbook. If a spell is not in the
  spellbook or the message format does not identify its source, the number remains
  visible without an icon.
- Incoming damage has no source spell name in the classic COMBAT_TEXT_UPDATE event,
  so it intentionally has no source icon in this version.


0.3.3 FIX: Replaced string.match calls with Lua 5.0-compatible string.find captures.


0.3.3 CHANGE: Reduced icon-to-number gap from 5 pixels to 1 pixel.

Damage display: exact values below 1,000; whole-thousand shorthand from 1k through 999k. Spell icons are anchored 1 pixel to the left of the measured text width, so they follow the number as its digit count changes.


0.3.4 CHANGE: Spell icons now track the rendered number width dynamically instead of anchoring to the fixed-width text frame.
